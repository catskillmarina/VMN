<?php include 'vars.php'; ?>
	<item>
		<title>A discussion with authors of the statement at leftrenewal.net</title>
		<link><?php echo $baseurl?>/2024/01/20/a-discussion-with-authors-of-the-statement-at-leftrenewal-net/</link>
		<pubDate>Sat, 20 Jan 2024 20:17:43 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=233</guid>
		<description><![CDATA[
<p>In this episode we discuss the statement at leftrenewal.net with 2 of the 3 authors. The statement, which was read in its entirety in volume 3 episode 29 talks about antisemetism on the left and various problems with the current left movement. The statement which was prompted by uncritical support for the Oct 7 2023 attack by Hamas on Israel has gained unexpected attention.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2024/01/Vol3_Ep30_A_Discussion_With_leftrenewal_dot_net.mp3" length="94344719" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:05:31</itunes:duration>
	</item>
	<item>
		<title>The statement at leftrenewal.net</title>
		<link><?php echo $baseurl?>/2024/01/16/the-statement-at-leftrenewal-net/</link>
		<pubDate>Tue, 16 Jan 2024 08:20:01 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=230</guid>
		<description><![CDATA[
<p>This episode is a reading of the statement at leftrenewal.net and a plug to raise funds for ddosecrets.com &#8211; a very important  internet library of leaked and hacked documents.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2024/01/Volume3_Episode29.mp3" length="81946127" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>56:54</itunes:duration>
	</item>
	<item>
		<title>A discussion with free speech Hero Lee Morrigan</title>
		<link><?php echo $baseurl?>/2024/01/13/a-discussion-with-free-speech-hero-lee-morrigan/</link>
		<pubDate>Sat, 13 Jan 2024 06:38:23 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=227</guid>
		<description><![CDATA[
<p>In this episode we discuss the free speech case of Lee Morrigan who was hauled in front of a Vermont Secret Inquest in the effort to compel them to reveal a journalistic source. We also discuss some of the right wingers constantly try to go after Lee as an open trans person.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2024/01/VMN-Vol3-Episode28-Lee-Morrigan-and-Free-Speech-final.mp3" length="107315938" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:14:31</itunes:duration>
	</item>
	<item>
		<title>Olivia Taylor speaks out on the citation of Bill Oetjen</title>
		<link><?php echo $baseurl?>/2023/12/28/olivia-taylor-speaks-out-on-the-citation-of-bill-oetjen/</link>
		<pubDate>Thu, 28 Dec 2023 04:51:59 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=223</guid>
		<description><![CDATA[
<p>Olivia Taylor tells the story behind the recent citation of Bill Oetjen for putting up bigoted stickers all over Burlington Vermont.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/12/Vol_3_Ep_27_Discussing_Sticker_Wars_with_Olivia_Taylor.mp3" length="75941486" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>52:44</itunes:duration>
	</item>
	<item>
		<title>Daryle Lamont Jenkins on BTV Channel 17</title>
		<link><?php echo $baseurl?>/2023/11/26/daryle-lamont-jenkins-on-btv-channel-17/</link>
		<pubDate>Sun, 26 Nov 2023 22:19:12 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=219</guid>
		<description><![CDATA[
<p>This episode is a rebroadcast of a discussion between Meghan O&#8217;Rourke and Daryle Lamont Jenkins regarding free speech and an intro on what the One People&#8217;s Project does to oppose fascism, fascists and racists.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/11/Vol3_Ep26_Daryle_Lamont_Jenkins_discusses_free_speech_on_Ch17.mp3" length="24437545" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>36:38</itunes:duration>
	</item>
	<item>
		<title>Epona Rose Speaks out</title>
		<link><?php echo $baseurl?>/2023/11/11/epona-rose-speaks-out/</link>
		<pubDate>Sat, 11 Nov 2023 23:06:09 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=215</guid>
		<description><![CDATA[
<p>Epona Rose speaks out about transphobia and her recent assault and arrest for self-defense in so called Flagstaff Arizona.<br><br>There are some issues with the sound quality but i have done my best to make this listen-able. <br><br>Trigger warnings for sexual assault, abusive jail conditions and transphobia apply.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/11/Vol3_Episode25_Epona_Rose.mp3" length="32963974" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>40:38</itunes:duration>
	</item>
	<item>
		<title>The Brawl in BTV</title>
		<link><?php echo $baseurl?>/2023/10/19/the-brawl-in-btv/</link>
		<pubDate>Thu, 19 Oct 2023 04:24:58 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=211</guid>
		<description><![CDATA[
<p>Conversation about Free Speech with Sandy Baird and Marina Brown 10/11/2023 &#8211; A discussion about free speech and it&#8217;s limits turns into a callout for Sandy platforming the anti-trans group LGB Alliance. <br><br>Trigger warnings for conflict and transphobia.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/10/Vol3_Ep24-The-Brawl-In-BTV.mp3" length="33046439" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>42:21</itunes:duration>
	</item>
	<item>
		<title>Discussion at YIVO of left wing antisemetism</title>
		<link><?php echo $baseurl?>/2023/10/17/discussion-at-yivo-of-left-wing-antisemetism/</link>
		<pubDate>Tue, 17 Oct 2023 03:29:49 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=208</guid>
		<description><![CDATA[
<p>The horrors coming out of Israel/Palestine have been bringing out the worst in many people.</p>



<p>The attacks on Israeli civilians and the corresponding wholescale killing of Palestinian civilians in Gaza has created fertile ground for Islamophobia and antisemetism.</p>



<p>In this episode i am rebroadcasting a discussion of Antisemetism on the left that was initially recorded on Tuesday May 4, 2021 at YIVO Institute for Jewish Research. Many thanks to Spencer Sunshine and YIVO for permission to use this material. It is especially relevant at the present moment.</p>



<p>The original video can be found at https://yivo.org/Leftists and athttps://spencersunshine.com/2021/04/06/yivo-las/ .</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/10/Leftists-on-Left-Wing-Antisemitism-panel.mp3" length="64742188" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:31:41</itunes:duration>
	</item>
	<item>
		<title>Talking with the Grassroots social and cultural center in Wroclaw Poland</title>
		<link><?php echo $baseurl?>/2023/09/27/talking-with-the-grassroots-social-and-cultural-center-in-wroclaw-poland/</link>
		<pubDate>Wed, 27 Sep 2023 20:42:59 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=204</guid>
		<description><![CDATA[
<p>In this episode we talk with Krzysztof from the Oddolne Centrum Społeczno Kulturalne &#8211; or Grassroots Social and Cultural Center in Wroclaw Poland. The center has come under repeated attack by neo-nazis but it continues to do it&#8217;s good work.<br><br>https://ocsk-postoj.wspolneoparcie.org/<br></p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/09/Vol3_Episode22.mp3" length="27822027" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>42:46</itunes:duration>
	</item>
	<item>
		<title>Antifascist: A Memoir of the Portland Uprising, 2016-2021</title>
		<link><?php echo $baseurl?>/2023/09/18/antifascist-a-memoir-of-the-portland-uprising-2016-2021/</link>
		<pubDate>Mon, 18 Sep 2023 05:12:38 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=199</guid>
		<description><![CDATA[
<p>In this episode we discuss the book &#8211; Antifascist: A Memoir of the Portland Uprising, 2016-2021, by Luis Enrique Marquez. We discuss the ups and downs of being an antifascist in Portland and some of the many controversies Luis has gotten involved in during his activist career. <br><br>Daryle Lamont Jenkins &#8211; Executive Director of the One Peoples Project is co-host.<br><br>Luis is the author of the book who graciously agreed to come talk on VMN !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/09/Volume3_Episode21.mp3" length="55423000" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:22:35</itunes:duration>
	</item>
	<item>
		<title>Talking with The Polish Grannies !</title>
		<link><?php echo $baseurl?>/2023/08/29/talking-with-the-polish-grannies/</link>
		<pubDate>Tue, 29 Aug 2023 20:50:47 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=195</guid>
		<description><![CDATA[
<p>In this episode we talk with Polskie Babscie &#8211; The Polish Grannies about the situation in Poland and the importance of the upcoming elections. The Polish Grannies have stood against the far right ruling party &#8211; PIS and it&#8217;s bigotry in the streets. Polskie Babscie shows that antifascism is not just for the young !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/08/Talking-With-Polskie-Babscie-The-Polish-Grannies.mp3" length="37339821" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>52:32</itunes:duration>
	</item>
	<item>
		<title>ACAB in Flagstaff AZ &#8211; Free Epona Rose !!</title>
		<link><?php echo $baseurl?>/2023/08/25/acab-in-flagstaff-az-free-epona-rose/</link>
		<pubDate>Fri, 25 Aug 2023 05:28:41 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=192</guid>
		<description><![CDATA[
<p>In this episode we discuss the situation of Epona Rose who was arrested for defending herself from a hateful attack. All this is happening in the backdrop of centuries of ONGOING oppression of the indigenous population by the colonial authorities. Colonialism and imperialism continues to poison the hearts of many living under them.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/08/ACAB-in-Flagstaff-Free-Epona-Rose.mp3" length="47063277" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:05:28</itunes:duration>
	</item>
	<item>
		<title>Discussion of the Andy Ngo trial with Lauren Regen.</title>
		<link><?php echo $baseurl?>/2023/08/17/discussion-of-the-andy-ngo-trial-with-lauren-regen/</link>
		<pubDate>Thu, 17 Aug 2023 02:42:59 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=188</guid>
		<description><![CDATA[
<p>In Vol 3 Episode 18 VMN discusses the Andy Ngo trial, legal issues around protest and free speech and the need for digital security.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/08/Lauren_Regen_Talks_About_The_Andy_Ngo_trial.mp3" length="39821087" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>54:11</itunes:duration>
	</item>
	<item>
		<title>CCTV Interviews Marina Brown about VTLEAKS</title>
		<link><?php echo $baseurl?>/2023/07/21/cctv-interviews-marina-brown-about-vtleaks/</link>
		<pubDate>Fri, 21 Jul 2023 12:25:31 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=184</guid>
		<description><![CDATA[
<p>This episode contains a recording of a CCTV interview of Marina Brown<br>regarding VTLEAKS.</p>



<p>This is the description from cctv.org</p>



<h2 class="wp-block-heading">The recording will be presented in whole as it was.</h2>



<p>Host Meghan O&#8217;Rourke interviews Marina Brown about VT Leaks, Vermont Transparency and Accountability.</p>



<p>For more information visit: www.vtleaks.org/</p>



<p>Production Date: 05/19/2023</p>



<p>WORKER<br>Jordan Mitchell</p>



<p>RELATED ISSUES<br>Economy &amp; Business</p>



<p>RELATED TAGS<br>accountability<br>documentation<br>free speech<br>leak</p>



<hr class="wp-block-separator has-alpha-channel-opacity"/>



<p>Creative commons licensed &#8211; on the CCTV website and<br>on youtube.</p>



<p>Attribution-NonCommercial-ShareAlike 4.0 International</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/07/Vol3_Ep17.mp3" length="24128105" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>31:37</itunes:duration>
	</item>
	<item>
		<title>Forum: Fighting Back Against Fascism and the Far Right feat.Daryle Lamont Jenkins, John Leslie and Brittany W.</title>
		<link><?php echo $baseurl?>/2023/07/20/forum-fighting-back-against-fascism-and-the-far-right-feat-daryle-lamont-jenkins-john-leslie-and-brittany-w/</link>
		<pubDate>Thu, 20 Jul 2023 05:57:06 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=176</guid>
		<description><![CDATA[
<p>PHILADELPHIA, PA &#8211; Forum: Fighting Back Against Fascism and the Far Right feat. Daryle Lamont Jenkins, John Leslie and Brittany W.</p>



<p>Tue Jul 18th 6:30pm &#8211; 9:00pm (EDT)<br>William Way LGBT Community Center,<br>1315 Spruce St, Philadelphia, PA 19107, USA<br></p>



<p>Forum: Fighting Back Against Fascism and the Far Right</p>



<p>Workers’ Voice presents a panel discussion on the rise of the far right, the current offensive against queer and trans people, and how we can fight back.</p>



<p>Speakers:</p>



<p>Daryle Lamont Jenkins &#8211; antifascist researcher, founder and executive director of One People’s Project, and editor of Idavox.</p>



<p>John Leslie &#8211; labor, socialist, and antifascist activist, Workers’ Voice.</p>



<p>Brittany W. &#8211; educator speaking on the far-right offensive against LGBTQ people in the schools.</p>



<p>Racism, anti-Semitism, sexism, homophobia, and transphobia are on the rise — stoked by lies and conspiracy theories. The result is a sharp increase in hate crimes against oppressed peoples. This hate is being brought forth not only by violent fascists like the Proud Boys and Patriot Front but also by groups like Moms for Liberty and politicians of the GOP. Trumpism has set these forces in motion in recent years, but the roots of the current far-right surge go deeper into the history of racism that is so ingrained in U.S. capitalist society.</p>



<p>White supremacist ideas like the “great replacement theory” and Christian nationalism are being mainstreamed in one of the two bourgeois parties, as the Republicans increasingly take on features of a far-right party. But the Democratic Party, the traditional party of slavery and Jim Crow segregation, likewise facilitates the current climate of prejudice, as it seeks to maintain the status quo on behalf of capitalism. The Biden administration’s clamping down against Latino and Haitian migrants on the border is one example of its reactionary policies.</p>



<p>Stopping the far right will take a mass movement of millions. Cops, capitalist courts, and liberal politicians won’t save us. The key to opposing the far right is independent, united front mass counter-mobilization by the working class and oppressed. It also means exercising our right to self-defense in an organized way.</p>



<hr class="wp-block-separator has-alpha-channel-opacity"/>



<p>Again &#8211; that was the advertisement for the event. This forum presents a somewhat different approach than our last interviewee &#8211; Alexander Reid Ross.</p>



<p><br>A warning to the listeners &#8211; the sound quality is rough in some parts particularly the end portion with the question and answer segment but we believe that this is very much worthwhile listening to.</p>



<p></p>



<p>Listen to the podcast at:</p>



<p><a href="<?php echo $baseurl?>/2023/07/20/forum-fighting-back-against-fascism-and-the-far-right-feat-daryle-lamont-jenkins-john-leslie-and-brittany-w/"><?php echo $baseurl?>/2023/07/20/forum-fighting-back-against-fascism-and-the-far-right-feat-daryle-lamont-jenkins-john-leslie-and-brittany-w/</a></p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/07/vol_3-ep_16-Final.mp3" length="42325476" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:12:22</itunes:duration>
	</item>
	<item>
		<title>A discussion with Alexander Reid Ross</title>
		<link><?php echo $baseurl?>/2023/07/15/a-discussion-with-alexander-reid-ross/</link>
		<pubDate>Sat, 15 Jul 2023 04:58:28 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=173</guid>
		<description><![CDATA[
<p>I discuss the phenomenon of Patriotic Socialism, MAGA Communism and the upcoming fake peace rally in NYC with Alexander Reid Ross.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/07/Vol_3_Ep_15.mp3" length="33271509" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>56:14</itunes:duration>
	</item>
	<item>
		<title>Legal Self Defense with Attys Kira Kelley and Claire Glenn</title>
		<link><?php echo $baseurl?>/2023/02/27/legal-self-defense-with-attys-kira-kelley-and-claire-glenn/</link>
		<pubDate>Mon, 27 Feb 2023 22:01:00 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=164</guid>
		<description><![CDATA[
<p>In this episode we discuss legal self defense with self described punk lawyer Kira Kelley and every prosecutors nightmare &#8211; Claire Glenn. This is good listening for anyone in this overpoliced so called country !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/02/Vol_3_Episode_13.mp3" length="68556232" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:51:11</itunes:duration>
	</item>
	<item>
		<title>Chat with Margaret Elisabeth Regarding Green Party Matters</title>
		<link><?php echo $baseurl?>/2023/02/26/chat-with-margaret-elisabeth-regarding-green-party-matters/</link>
		<pubDate>Sun, 26 Feb 2023 00:20:10 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=160</guid>
		<description><![CDATA[
<p>In this episode we talk with Margaret Elisabeth regarding the fight to add a sex work plank to the Green Party Platform, reactionary infiltrators, the fashy Rage Against the War Machine rally and MORE !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/02/Vol_3_Episode_12.mp3" length="58486277" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:40:51</itunes:duration>
	</item>
	<item>
		<title>Talking about Aunt Jenny</title>
		<link><?php echo $baseurl?>/2023/01/10/talking-about-aunt-jenny/</link>
		<pubDate>Tue, 10 Jan 2023 17:32:10 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=156</guid>
		<description><![CDATA[
<p>A relatively unknown trans woman named Aunt Jenny or Jenstar took care of dozens if not more internet trans kids changing trans culture almost single handedly.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2023/01/Vol3_Episode11.mp3" length="32654665" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>56:36</itunes:duration>
	</item>
	<item>
		<title>A Discussion of Grand Jury Resistance</title>
		<link><?php echo $baseurl?>/2022/10/26/a-discussion-of-grand-jury-resistance/</link>
		<pubDate>Wed, 26 Oct 2022 07:20:13 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=152</guid>
		<description><![CDATA[
<p>Listen to a discussion of grand jury resistance with lawyers Sandra Freeman  and Kira Kelley and grand jury resister Jeremy Hammond.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/10/Vol3_Ep10.mp3" length="40653325" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:04:24</itunes:duration>
	</item>
	<item>
		<title>Martia Abernathy response to the previous episode</title>
		<link><?php echo $baseurl?>/2022/10/12/martia-abernathy-response-to-the-previous-episode/</link>
		<pubDate>Wed, 12 Oct 2022 14:24:58 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=147</guid>
		<description><![CDATA[
<p>This is the response of Martia Abernathy to the previous episode regarding the TERF provocation at Burlington Pride and the Outright truck pull. Martia is a long time transactivist living in the UK. She is a podcaster. Her social media, podcasts and broadcasts can be found at https://martiabernathy.com .</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/10/Vol3_Ep9.mp3" length="10989914" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>13:51</itunes:duration>
	</item>
	<item>
		<title>VMN Vol 3 Episode 8 &#8211; De-escalators talk about the Fred Sargeant incidents in Burlington VT.</title>
		<link><?php echo $baseurl?>/2022/10/11/vmn-vol-3-episode-8-de-escalators-talk-about-the-fred-sargeant-incidents-in-burlinton-vt/</link>
		<pubDate>Tue, 11 Oct 2022 20:03:08 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=142</guid>
		<description><![CDATA[
<p>In this episode de-escalators/peacekeepers at Burlington VT pride and the Outright truck pull event discuss their viewpoint of the incidents surrounding Fred Sargeant and the LGB Alliance.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/10/Vol3_Episode8.mp3" length="37203599" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>57:42</itunes:duration>
	</item>
	<item>
		<title>VMN Volume 3 Episode 7 &#8211; All out against the white Supremacist AmRen Convention</title>
		<link><?php echo $baseurl?>/2022/10/10/vmn-volume-3-episode-7-all-out-against-the-white-supremacist-amren-convention/</link>
		<pubDate>Mon, 10 Oct 2022 15:41:41 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=138</guid>
		<description><![CDATA[
<p>VMN V3 E7 &#8211; An interview with Daryl Lamont Jenkins of the antifascist One Peoples Project regarding opposition to the white supremacist American Renaissance convention that will be held at the Montgomery Bell Park in Burns TN Nov 18-20 2022. <br><br>All out against white supremacy !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/10/Vol3_Episode7.mp3" length="21755367" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>36:38</itunes:duration>
	</item>
	<item>
		<title>VMN Volume 3 Episode 6 - an interview with former Prairie Fire Organizing Committee member Melinda Powers</title>
		<link><?php echo $baseurl?>/2022/10/05/vmn-volume-3-episode-6-an-interview-with-former-prairie-fire-organizing-committee-member-melinda-powers/</link>
		<pubDate>Wed, 05 Oct 2022 04:33:31 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=134</guid>
		<description><![CDATA[
<p>Vol6 Episode 3 is an interview with a former member of the Prairie Fire Organzing Commitee. Prairie Fire was active from the 70&#8217;s to the 90&#8217;s.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/10/Vol3_Ep6-Final.mp3" length="24517644" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>40:06</itunes:duration>
	</item>
	<item>
		<title>Margaret Elisabeth a co-chair of Green Party Lavender caucus</title>
		<link><?php echo $baseurl?>/2022/08/13/margaret-elisabeth-a-co-chair-of-green-party-lavender-caucus/</link>
		<pubDate>Sat, 13 Aug 2022 17:53:06 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=129</guid>
		<description><![CDATA[
<p>An interview with Margaret Elisabeth a co-chair of Green Party Lavender caucus and a co-chair of the Green Party of the US. The Green party has become a front in the recent wave of culture war bigotry. We discuss transphobia, the anti-crt panic and fascist entryism in the environmental movement. This is a must-listen episode !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/08/Vol_3_Ep_5.mp3" length="87393296" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>2:07:10</itunes:duration>
	</item>
	<item>
		<title>An interview with a Texas history teacher</title>
		<link><?php echo $baseurl?>/2022/08/13/an-interview-with-a-texas-history-teacher/</link>
		<pubDate>Sat, 13 Aug 2022 08:25:27 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=125</guid>
		<description><![CDATA[
<p>Scott Frank is a history teacher who works at IDEA Frontier, a public school in Brownsville, Texas. For reference, IDEA stands for &#8220;Individuals Dedicated to Excellence and Achievement&#8221;. In his own words, he describes the anti-CRT backlash as &#8220;an attack on educators, the understanding of the past and, worst of all, on our students fully comprehending and coming to terms with what happened and how to move forward&#8221;.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/08/Volume_3_Episode_4.mp3" length="27839740" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>45:06</itunes:duration>
	</item>
	<item>
		<title>Vol 3 Episode 3 &#8211; An interview with a public school Latin teacher</title>
		<link><?php echo $baseurl?>/2022/08/12/vol-3-episode-3-an-interview-with-a-public-school-latin-teacher/</link>
		<pubDate>Fri, 12 Aug 2022 19:57:41 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=121</guid>
		<description><![CDATA[
<p>*Andrea Weiskopf *- Andrea is an English and Latin teacher who works<br>with Loudoun County Public Schools. I have not found any news articles<br>about her receiving harassment from right-wingers, but she is an active<br>supporter of social justice and has counter-protested against many<br>far-right gatherings. <br><br>Twitter: @latinsaxa<br>Blog: andreaweiskopf.net</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/08/Episode_3.mp3" length="27444026" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>54:18</itunes:duration>
	</item>
	<item>
		<title>Vermont Movement News Vol 3 Episode 2 &#8211; Melissa Grandi Statz</title>
		<link><?php echo $baseurl?>/2022/08/03/vermont-movement-news-vol-3-episode-2-melissa-grandi-statz/</link>
		<pubDate>Wed, 03 Aug 2022 16:05:39 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=116</guid>
		<description><![CDATA[
<p>Vermont Movement News vol 3 Episode 2</p>



<p>Daryle Lamont Jenkins, the executive director of the One Peoples Project<br>todays co-host.</p>



<p>In this episode we will be interviewing Melissa Grandi Statz<br>Melissa was a social studies teacher who works at Dyer Elementary School in Burlington, Wisconsin. In August 2020 &#8211; a few months after George Floyd&#8217;s murder, Melissa taught classes about racism in response to questions from her students who the murders by police. A right-wing Facebook group eventually caught wind of lessons and a slew of harassment and death threats began. Her story was covered by PBS Wisconsin Education and NBC News. <br><br>https://pbswisconsineducation.org/akateacher/talking-about-race/</p>



<p><a href="https://www.nbcnews.com/news/us-news/how-one-teacher-s-black-lives-matter-lesson-divided-small-n1244566">https://www.nbcnews.com/news/us-news/how-one-teacher-s-black-lives-matter-lesson-divided-small-n1244566</a></p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/08/Melissa_Grandi_Statz-final.mp3" length="34572381" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>55:04</itunes:duration>
	</item>
	<item>
		<title>Vermont Movement News vol 3 Episode 1 &#8211; An interview with Brian McCrae</title>
		<link><?php echo $baseurl?>/2022/08/03/vermont-movement-news-vol-3-episode-1-an-interview-with-brian-mccrae/</link>
		<pubDate>Wed, 03 Aug 2022 15:53:22 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=113</guid>
		<description><![CDATA[
<p>In this episode we will be interviewing Brian McCrae, a<br>teacher of photography, video production, and graphic design teacher at North Country Union High School in Newport Vermont up near the canadian border. Vermont has a reputation for liberalism and progressive values, however it has not been immune against the far-right&#8217;s crusade against anti-racist values and tolerance.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2022/08/Brian_McCrae-Take2.mp3" length="33476648" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>56:00</itunes:duration>
	</item>
	<item>
		<title>Vol 2 Ep 6 &#8211; The Spanish Civil War with Beth Foster</title>
		<link><?php echo $baseurl?>/2020/12/23/vol-2-ep-6-the-spanish-civil-war-with-beth-foster/</link>
		<pubDate>Wed, 23 Dec 2020 15:33:05 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=105</guid>
		<description><![CDATA[
<p>Volume 2 Episode 6 features an interview with Beth Foster regarding the experience of Americans who fought in the Spanish Civil War and the aftermath of their experience. Fascinating !</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/12/vol-2-ep-6-final.mp3" length="5209543" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>28:56</itunes:duration>
	</item>
	<item>
		<title>VMN Vol 2 Ep 5 - Spencer Sunshine - Antisemitism on the left.</title>
		<link><?php echo $baseurl?>/2020/11/22/spencer-sunshine-talk-on-antisemitism-on-the-left-2010/</link>
		<pubDate>Sun, 22 Nov 2020 17:50:25 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=100</guid>
		<description><![CDATA[
<p>VMN Vol 2 Episode 5 re-broadcasts Spencer Sunshines presentation at the 2010 ARA convention discussing antisemitism on the left. I believe this is well worthwhile listening to even though the sound quality is not the best.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/11/vol2-ep-5-final-1.mp3" length="12346288" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>1:08:35</itunes:duration>
	</item>
	<item>
		<title>What about the elections ? &#8211; A discussion with Shawn Pratt and Duane.</title>
		<link><?php echo $baseurl?>/2020/11/18/what-about-the-elections-a-discussion-with-shawn-pratt-and-duane/</link>
		<pubDate>Wed, 18 Nov 2020 16:02:39 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=97</guid>
		<description><![CDATA[
<p>VMN discusses the elections and related topics with Shawn Pratt and Duane from New Hampshire. Podcast includes a wonderful track from &#8216;Grindwork Fresh&#8217;.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/11/vol_2-ep_4.mp3" length="7960870" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>44:14</itunes:duration>
	</item>
	<item>
		<title>Inteview with Raymond Tee Tee Moore, Shawn Pratt and Daryl Lamont Jenkins</title>
		<link><?php echo $baseurl?>/2020/10/30/inteview-with-raymond-tee-tee-moore-shawn-pratt-and-daryl-lamont-jenkins/</link>
		<pubDate>Fri, 30 Oct 2020 03:15:23 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=93</guid>
		<description><![CDATA[
<p>VMN Vol 2 Episode 3 features an interview with Raymond Tee Tee Moore from North Adams Ma, Shawn Pratt from Bennington VT and Daryl Lamont Jenkins of the One Peoples Project out of NJ. They discuss BLM and the many challenges and threats they have faced organizing for racial justice.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/10/vol2_ep3-final.mp3" length="8697835" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:explicit>false</itunes:explicit>
		<itunes:duration>48:19</itunes:duration>
	</item>
	<item>
		<title>Interview with Vermont congressional candidate Chris Helali</title>
		<link><?php echo $baseurl?>/2020/10/25/interview-with-vermont-congressional-candidate-chris-helalai/</link>
		<pubDate>Sun, 25 Oct 2020 06:45:45 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=89</guid>
		<description><![CDATA[]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/10/Vol2-EP2.mp3" length="9752360" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>54:11</itunes:duration>
	</item>
	<item>
		<title>VMN Vol II Episode I - An interview with Bennington Activists and Mentor Shawn Pratt</title>
		<link><?php echo $baseurl?>/2020/10/23/vmn-vol-ii-episode-i-an-interview-with-shawn-pratt/</link>
		<pubDate>Fri, 23 Oct 2020 20:01:58 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=86</guid>
		<description><![CDATA[]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2020/10/Vol2-EP1.mp3" length="5359625" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>29:47</itunes:duration>
	</item>
	<item>
		<title>An interview with Eilís Ní Fhlannagáin</title>
		<link><?php echo $baseurl?>/2019/11/23/an-interview-with-eilis-ni-fhlannagain/</link>
		<pubDate>Sat, 23 Nov 2019 08:05:21 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=75</guid>
		<description><![CDATA[
<p>This episode features an interview with longtime activist Eilís Ní Fhlannagáin. She discusses activism in Ireland, strategies with regards to anarchism, the fight against bigotry and trans rights. This is a good discussion on tactics.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/11/Vol_1_Episode_11.mp3" length="12492538" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:09:24</itunes:duration>
	</item>
	<item>
		<title>Vol 1 Episode 10 &#8211; Anti-Muslim speaker deplatformed twice and a right wing radio host fired.</title>
		<link><?php echo $baseurl?>/2019/10/13/vol-1-episode-10-anti-muslim-speaker-deplatformed-twice-and-a-right-wing-radio-host-fired/</link>
		<pubDate>Sun, 13 Oct 2019 03:18:03 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=70</guid>
		<description><![CDATA[
<p>Vol 1 Episode 10 features an interview with Asma Elhuni who was centrally involved in the deplatforming of anti-muslim speaker and author Robert Spencer from not one but 2 venues in New Hampshire.  This campaign may also have cost a right wing radio host his job for his aggressive social media comments regarding this event.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/10/Volume_1_Episode_10.mp3" length="9564197" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>53:08</itunes:duration>
	</item>
	<item>
		<title>ACAB or The Boston Police Riot at Straight Pride Hate Rally !</title>
		<link><?php echo $baseurl?>/2019/09/12/acab-or-the-boston-police-riot-at-straight-pride-hate-rally/</link>
		<pubDate>Thu, 12 Sep 2019 19:00:03 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=66</guid>
		<description><![CDATA[
<p>Volume 1 Episode 9 of VMN has interviews from the hostess, Medic Mom, the elderly medic who was attacked by the cops, ruckus and an anonymous medic who did his duties as a medic even while being held hostage by the police.<br><br>The episode wraps up with an interview with Alison from the Torproject discussing digital security for activists as some people had their cell phones stolen by untrustworthy individuals at the event.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/09/Vol_1_Episode_9_The-_A31_2019_Police_Riot-Final-24k.mp3" length="16971984" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:34:17</itunes:duration>
	</item>
	<item>
		<title>All Out against the fascistic Straight Pride Aug 31 in Boston !</title>
		<link><?php echo $baseurl?>/2019/08/28/all-out-against-the-fascistic-straight-pride-aug-31-in-boston/</link>
		<pubDate>Wed, 28 Aug 2019 07:31:21 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=61</guid>
		<description><![CDATA[
<p>Volume 1 Episode 8 of Vermont Movement News. This is a shorter podcast for an emergency mobilization against the fascist Straight Pride Parade that is being held in Boston on Saturday August 31. The purpose of this podcast is to get as many people as possible to come out to oppose this right wing event.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/08/Volume_1_Episode_8_antifascist-mobilization-against-fascistic-straight-pride.mp3" length="3113568" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>17:18</itunes:duration>
	</item>
	<item>
		<title>Volume 1 Episode 7 &#8211; The fightback against ICE</title>
		<link><?php echo $baseurl?>/2019/08/21/volume-1-episode-7-the-fightback-against-ice/</link>
		<pubDate>Wed, 21 Aug 2019 09:35:13 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=56</guid>
		<description><![CDATA[
<p>Volume 1 Episode 7 of Vermont Movement News. This episode features  interviews with Julie Conason and Adrienne Cooper Smith who were arrested protesting the ICE data Center in Williston VT on July 28th. We also have an  interview with Scott Norman Rosenthal who was arrested protesting the ICE raids  in Hartford on Aug 14th.  The second interview will be the one<br> with Remi, a street medic who was at the tragic ICE vehicular attack on  protestors at the Wyatt Detention center in Rhode Island.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/08/Volume_1_Episode_7_The_Fightback_Against_ICE.mp3" length="16599391" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:32:13</itunes:duration>
	</item>
	<item>
		<title>FIP/Anti-ICE action in Hartford TSP VT and Anti-F35 action.</title>
		<link><?php echo $baseurl?>/2019/08/14/fip-anti-ice-action-in-hartford-tsp-vt-and-anti-f35-action/</link>
		<pubDate>Wed, 14 Aug 2019 16:16:12 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=50</guid>
		<description><![CDATA[
<p>Volume 1 Episode 6 of Vermont Movement News. This episode features interviews with Asma Alhouni and Kira Kelley who were at the July 30 2019 action at the Hartford Select Board discussing a FIP (Fair and Impartial Policing Policy that would forbid the Hartford police from collaborating or colluding with Federal ICE agents. </p>



<p>After discussing the situation in Hartford we will move onto a reportback and discussion with Jenifer Decker from the movement to stop nuclear bombers from being based in South Burlington at the Burlington International Airport.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/08/Volume_1_Episode_6_Occupy_Hartford_High_for_FIP_and_Against_ICE_and_Oppose_F35.mp3" length="37436321" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:00:56</itunes:duration>
	</item>
	<item>
		<title>Volume 1 Episode 5 &#8211; an interview with Red.</title>
		<link><?php echo $baseurl?>/2019/08/13/volume-1-episode-5-an-interview-with-red/</link>
		<pubDate>Tue, 13 Aug 2019 19:22:56 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=46</guid>
		<description><![CDATA[
<p>Volume 1 Episode 5 of Vermont Movement News. This episode features an interview with Red who was present at Occupy/Decolonize Oakland, the infamous &#8220;Battle of Berkely&#8221; and the protest that de-platformed Milo Yanappolis. Be forewarned that there will be discussion of police and far right brutality and violence.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/08/vol-1-Episode-5-Red-on-combatting-the-alt-right-battle-of-berkely-deplatform-milo.mp3" length="40838441" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:03:38</itunes:duration>
	</item>
	<item>
		<title>Volume 1 Episode 4</title>
		<link><?php echo $baseurl?>/2019/07/29/volume-1-episode-4/</link>
		<pubDate>Mon, 29 Jul 2019 20:47:38 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=39</guid>
		<description><![CDATA[
<p>Welcome to Volume 1 Episode 4 of Vermont Movement News. This episode will  give reports back on the Extinction Rebellion protest in Montpelier Vermont, and an interview with a DUMP activist from Newport VT and an interview with an activist from Bennington whose well was contaminated with PFOA.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/07/Volume_1_Episode_4_Pam_Ladds_DUMP_Rosemarie_Jackowski_PFOA_Mindy_Blank_ER_DEMO_REPORTBACK-finalfinalcut-1.mp3" length="38617446" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>57:19</itunes:duration>
	</item>
	<item>
		<title>Vermont Movement News Vol 1 Episode 3</title>
		<link><?php echo $baseurl?>/2019/07/17/vermont-movement-news-vol-1-episode-3/</link>
		<pubDate>Wed, 17 Jul 2019 05:38:43 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=24</guid>
		<description><![CDATA[
<p>Vermont Movement News Vol 1 Episode 3 &#8211; This episode features a discussion with Mindy Blank of Central Vermont Extinction rebellion explaining what their movement is about and a discussion on tactics.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/07/Volume1_Episode3.mp3" length="20373081" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>42:05</itunes:duration>
	</item>
	<item>
		<title>Vermont Movement News Volume 1 Episode 2</title>
		<link><?php echo $baseurl?>/2019/07/10/vermont-movement-news-volume-1-episode-2/</link>
		<pubDate>Wed, 10 Jul 2019 23:08:25 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=15</guid>
		<description><![CDATA[
<p>Volume 1 Episode 2 of Vermont Movement News. This episode will  give reports back on the 4th of July protest against ICE in Bristol Vermont  and a brief report back from the alt-lite so called &#8220;Defend Free Speech&#8221;  Rally in Washington DC. We were fantastically lucky to get an interview  with researcher Gwen Snyder who has apparenty been targetted by the Proud Boys  in retaliation for her research. Finally we will have a discussion with  medic mom regarding the alt-lite/proud boy rally in DC with footage from the  event.</p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/07/Volume_1_Episode_2.mp3" length="31559727" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
		<itunes:duration>1:01:29</itunes:duration>
	</item>
	<item>
		<title>Vermont Movement News Vol 1 Episode 1</title>
		<link><?php echo $baseurl?>/2019/07/05/vermont-movement-news-vol-1-episode-1/</link>
		<pubDate>Fri, 05 Jul 2019 08:20:01 +0000</pubDate>
		<guid isPermaLink="false"><?php echo $baseurl?>/?p=10</guid>
		<description><![CDATA[
<p>Vermont Movement News Vol 1 Episode 1 &#8211; This episode features report backs from Bennington Pride, The Radical Pride in Burlington, The Migrant Justice protest in Newport, the Anti-Ice protest in Burlington and a discussion of conspiracy theories and why people buy into them and a bit more !<br><br><a href="<?php echo $baseurl?>/wp-content/uploads/2019/07/vol1-episode1.mp3"><?php echo $baseurl?>/wp-content/uploads/2019/07/vol1-episode1.mp3</a><br><br>If you have a bittorrent client we would very much appreciate you grabbing and seeding this for us !</p>



<p><a href="<?php echo $baseurl?>/wp-content/uploads/2019/07/vol1-episode1.mp3.torrent"><?php echo $baseurl?>/wp-content/uploads/2019/07/vol1-episode1.mp3.torrent</a><br><br></p>]]></description>
		<enclosure url="<?php echo $baseurl?>/wp-content/uploads/2019/07/vol1-episode1.mp3" length="30112116" type="audio/mpeg" />
		<itunes:author>Vermont Movement News</itunes:author>
		<itunes:episodeType>full</itunes:episodeType>
	</item>
